/**
 * Anvex Pi engine driver — runs inside the app's :node process.
 *
 * Android cannot exec a node binary, so Pi's CLI bundle is imported into
 * THIS process: process.argv is preset for RPC mode and process.stdin /
 * process.stdout are swapped for an in-memory loopback BEFORE the import
 * (Pi's RPC mode reads commands from stdin and writes JSONL records to
 * stdout). The driver exposes a localhost control socket; the Kotlin
 * PiEngine speaks Pi's own JSONL protocol over it, nearly verbatim:
 *
 *   Kotlin -> driver : first line = config JSON (consumed by the driver),
 *                      then Pi RPC commands + extension_ui_responses.
 *   driver -> Kotlin : `ANVEX_PI_PORT <n>` on stdout (via the runtime's
 *                      line channel) announces the control port; after
 *                      config, every Pi record is relayed as-is.
 *
 * The provider API key arrives ONLY inside the config line, is placed in
 * this process's environment for Pi's models.json `$ANVEX_PI_API_KEY`
 * interpolation, and is never written to disk or logged.
 *
 * Teardown is host-managed (Phase-2 finding): Pi keeps the event loop
 * alive and process.exit() does not end the embedded libnode loop, so
 * the host stops the :node process once a run settles.
 *
 * argv: [workdirAbs, runtimeDirAbs]
 *   workdirAbs   — project workspace (Pi's cwd; tool effects land here)
 *   runtimeDirAbs— extracted pi-runtime (pi/, ext/, vendor/)
 * State: agentDir is <workdirAbs>/.anvex-pi/agent unless the config
 * overrides it (tests do); sessions persist there across runs.
 */
import net from "node:net";
import { PassThrough } from "node:stream";
import { createInterface } from "node:readline";
import { mkdirSync, writeFileSync } from "node:fs";
import { join, resolve } from "node:path";
import { pathToFileURL } from "node:url";

const [workdirArg, runtimeDirArg] = process.argv.slice(2);
const workdir = resolve(workdirArg);
const runtimeDir = resolve(runtimeDirArg);
const realStdout = process.stdout;
const realExit = process.exit.bind(process);

let control = null; // the single Kotlin socket
let toPi = null;
let booted = false;

function fatal(msg) {
	try { realStdout.write(`ANVEX_PI_FATAL ${msg}\n`); } catch { /* noop */ }
	realExit(1);
}

const server = net.createServer((socket) => {
	if (control) { socket.destroy(); return; } // one client only
	control = socket;
	socket.setEncoding("utf8");
	const rl = createInterface({ input: socket, crlfDelay: Infinity });
	let configSeen = false;
	rl.on("line", (line) => {
		if (!line.trim()) return;
		if (!configSeen) {
			configSeen = true;
			boot(JSON.parse(line)).catch((err) => fatal(`boot failed: ${err && err.message || err}`));
			return;
		}
		// Pi RPC command or extension_ui_response — relay verbatim.
		if (toPi) toPi.write(line + "\n");
	});
	socket.on("close", () => {
		// Host gone: end Pi's stdin (best effort) and let the host kill us.
		try { toPi?.end(); } catch { /* noop */ }
	});
	socket.on("error", () => { /* host teardown will follow */ });
});
server.on("error", (err) => fatal(`control server: ${err.message}`));
server.listen(0, "127.0.0.1", () => {
	const port = server.address().port;
	realStdout.write(`ANVEX_PI_PORT ${port}\n`);
});

async function boot(config) {
	if (booted) return;
	booted = true;
	const agentDir = resolve(config.agentDir || join(workdir, ".anvex-pi", "agent"));
	mkdirSync(agentDir, { recursive: true });
	process.env.HOME = agentDir;
	process.env.PI_CODING_AGENT_DIR = agentDir;
	if (typeof config.apiKey === "string" && config.apiKey) {
		process.env.ANVEX_PI_API_KEY = config.apiKey;
	}
	if (config.modelsJson) {
		writeFileSync(join(agentDir, "models.json"), JSON.stringify(config.modelsJson, null, 2));
	}
	process.chdir(workdir);

	toPi = new PassThrough();
	const fromPi = new PassThrough();
	Object.defineProperty(process, "stdin", { value: toPi, configurable: true });
	Object.defineProperty(process, "stdout", { value: fromPi, configurable: true });

	const out = createInterface({ input: fromPi, crlfDelay: Infinity });
	out.on("line", (line) => {
		if (control && !control.destroyed) {
			try { control.write(line + "\n"); } catch { /* host gone */ }
		}
	});

	const argv = [
		process.execPath,
		join(runtimeDir, "pi", "dist", "bundle", "cli.js"),
		"--mode", "rpc",
		"--session-dir", join(agentDir, "sessions"),
	];
	if (config.providerName) argv.push("--provider", config.providerName);
	if (config.modelId) argv.push("--model", config.modelId);
	if (config.sessionFile) argv.push("--session", config.sessionFile);
	argv.push("-e", join(runtimeDir, "ext", "gateway.ts"));
	for (const extra of config.extraExtensions ?? []) argv.push("-e", extra);
	process.argv = argv;

	await import(pathToFileURL(argv[1]).href);
}
