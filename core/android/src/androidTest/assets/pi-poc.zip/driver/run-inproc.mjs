/**
 * Phase-2 POC in-process driver — the DEVICE-shaped variant.
 *
 * No child processes (Android apps cannot exec a node binary): Pi's CLI is
 * imported into THIS Node process with process.argv preset for RPC mode and
 * process.stdin/stdout swapped for PassThrough streams BEFORE the import,
 * so Pi's JSONL protocol runs over an in-memory loopback. This file is the
 * rehearsal of the exact script that later runs inside Anvex's :node
 * process on the emulator.
 *
 * Results are written to <workdir>/results-inproc.json (the Kotlin test
 * reads the device twin of this file after the run).
 *
 * Usage: node run-inproc.mjs <piCliPath> <workdir> <extensionPath>
 */
import { PassThrough } from "node:stream";
import { createInterface } from "node:readline";
import { existsSync, readFileSync, writeFileSync, mkdirSync, rmSync } from "node:fs";
import { join, resolve } from "node:path";
import { pathToFileURL } from "node:url";

const [cliPath, workdirArg, extPath] = process.argv.slice(2);
const workdir = resolve(workdirArg);
rmSync(workdir, { recursive: true, force: true });
mkdirSync(workdir, { recursive: true });
const gatewayLog = join(workdir, "gateway-log.jsonl");
const resultsPath = join(workdir, "results-inproc.json");

// Keep a handle on the real stdout for our own reporting.
const realStdout = process.stdout;
const say = (s) => realStdout.write(s + "\n");
// Pi's CLI may install its own exit/shutdown handling once imported; the
// harness must retain a way to end this disposable process deterministically
// (on the first device run the graceful path left node::Start blocked and
// the runtime had to time the run out after the results were written).
const realExit = process.exit.bind(process);

// Isolate Pi's config/session state inside the workdir.
process.env.HOME = workdir;
process.env.POC_GATEWAY_LOG = gatewayLog;
process.chdir(workdir);

const t0 = Date.now();
const rssSamples = [];
const rssTimer = setInterval(() => {
	const m = process.memoryUsage();
	rssSamples.push(m.rss);
}, 100);

// --- the loopback swap -----------------------------------------------------
const toPi = new PassThrough();
const fromPi = new PassThrough();
Object.defineProperty(process, "stdin", { value: toPi, configurable: true });
Object.defineProperty(process, "stdout", { value: fromPi, configurable: true });
process.argv = [
	process.execPath,
	cliPath,
	"--mode", "rpc",
	"--no-session",
	"--provider", "poc",
	"--model", "poc-scripted",
	"-e", extPath,
];

// --- protocol client over the loopback ------------------------------------
const pending = new Map();
const eventCounts = {};
let settledResolve;
const settled = new Promise((r) => (settledResolve = r));
const rl = createInterface({ input: fromPi, crlfDelay: Infinity });
rl.on("line", (line) => {
	if (!line.trim()) return;
	let rec;
	try { rec = JSON.parse(line); } catch { return; }
	if (rec.type === "response" && rec.id && pending.has(rec.id)) {
		pending.get(rec.id)(rec);
		pending.delete(rec.id);
		return;
	}
	eventCounts[rec.type] = (eventCounts[rec.type] ?? 0) + 1;
	if (rec.type === "agent_settled") settledResolve(rec);
});
function command(id, obj) {
	return new Promise((res) => {
		pending.set(id, res);
		toPi.write(JSON.stringify({ id, ...obj }) + "\n");
	});
}

// Boot Pi in-process. The CLI main() never resolves in RPC mode; it runs
// until stdin ends, so do NOT await the import.
import(pathToFileURL(cliPath).href).catch((err) => {
	writeFileSync(resultsPath, JSON.stringify({ fatal: String(err && err.stack || err) }, null, 2));
	say("FATAL importing pi cli: " + err);
});

const stateResp = await command("req-1", { type: "get_state" });
const startupMs = Date.now() - t0;

const promptAt = Date.now();
const promptResp = await command("req-2", {
	type: "prompt",
	message: "Write the POC hello file, then try the shell step, then report.",
});
await Promise.race([settled, new Promise((r) => setTimeout(r, 60_000))]);
const taskMs = Date.now() - promptAt;
clearInterval(rssTimer);

const helloPath = join(workdir, "poc-out", "hello.txt");
const summary = {
	engine: "pi-rpc-inproc",
	piVersion: "1.4.0",
	nodeVersion: process.version,
	platform: `${process.platform}/${process.arch}`,
	startupMs,
	stateOk: stateResp?.success === true,
	promptAccepted: promptResp?.success === true,
	promptDisposition: promptResp?.data?.disposition ?? null,
	taskMs,
	eventCounts,
	peakRssMB: Math.round((Math.max(...rssSamples, process.memoryUsage().rss) / 1048576) * 10) / 10,
	helloWritten: existsSync(helloPath),
	helloContent: existsSync(helloPath) ? readFileSync(helloPath, "utf8") : null,
	pwnedExists: existsSync(join(workdir, "poc-out", "pwned.txt")),
	gatewayLog: existsSync(gatewayLog)
		? readFileSync(gatewayLog, "utf8").trim().split("\n").map((l) => JSON.parse(l))
		: [],
};
writeFileSync(resultsPath, JSON.stringify(summary, null, 2));
say(JSON.stringify(summary, null, 2));
// Teardown is HOST-managed (measured on Android): Pi's runtime keeps the
// event loop alive and process.exit() does not end the embedded libnode
// loop, so the host kills this disposable process once the results file
// is durable — the same one-shot contract as every Anvex node command.
// realExit is attempted as a best effort; the harness does the rest.
try { toPi.end(); } catch { /* stream may already be closed */ }
realExit(0);
