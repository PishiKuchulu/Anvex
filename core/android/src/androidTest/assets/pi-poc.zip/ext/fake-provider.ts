/**
 * Phase-2 POC extension for Pi — two jobs:
 *
 * 1. A scripted fake provider ("poc/poc-scripted") so the whole agent loop
 *    runs deterministically with NO network and NO API key:
 *      turn A -> toolCall write  (poc-out/hello.txt)
 *      turn B -> toolCall bash   (must be blocked by the gateway)
 *      turn C -> final text
 *    The script branches on the transcript (which tool results exist),
 *    not on a turn counter, so retries cannot desync it.
 *
 * 2. The approval-gateway stub: a tool_call hook implementing the POC
 *    policy — file tools allowed, bash blocked — logging every decision
 *    as a JSON line to $POC_GATEWAY_LOG. This is the exact integration
 *    point Anvex's CommandApprovalService would occupy in Phase 3.
 */
import { appendFileSync } from "node:fs";
// Device-bundle variant: the stream class comes from the vendored leaf
// module (pi-ai/dist/utils/event-stream.js, MIT) because the slim bundle
// ships no node_modules. Pi consumes the stream by async iteration +
// result(), so the class only needs to be protocol-faithful.
// @ts-ignore - vendored JS leaf module
import { createAssistantMessageEventStream } from "../vendor/event-stream.js";

type AssistantMessage = Record<string, unknown> & { content: unknown[] };
type Context = { messages: Array<Record<string, unknown>> };
type Model = { api: string; provider: string; id: string };
type SimpleStreamOptions = {
	onPayload?: (payload: unknown) => Promise<unknown>;
	onResponse?: (response: { status: number; headers: Record<string, string> }) => Promise<void>;
};
type ExtensionAPI = {
	registerProvider: (name: string, config: Record<string, unknown>) => void;
	on: (event: string, handler: (event: never) => Promise<unknown>) => void;
};

const GATEWAY_LOG = process.env.POC_GATEWAY_LOG || "gateway-log.jsonl";

function gatewayLog(record: Record<string, unknown>): void {
	try {
		appendFileSync(GATEWAY_LOG, JSON.stringify({ t: Date.now(), ...record }) + "\n");
	} catch {
		// logging must never break the loop
	}
}

function emptyUsage() {
	return {
		input: 0,
		output: 0,
		cacheRead: 0,
		cacheWrite: 0,
		totalTokens: 0,
		cost: { input: 0, output: 0, cacheRead: 0, cacheWrite: 0, total: 0 },
	};
}

function toolResultsSeen(context: Context): string[] {
	const names: string[] = [];
	for (const msg of context.messages) {
		if (msg.role === "toolResult") names.push((msg as { toolName?: string }).toolName ?? "?");
	}
	return names;
}

function streamScripted(model: Model, context: Context, options?: SimpleStreamOptions) {
	const stream = createAssistantMessageEventStream();
	(async () => {
		const output: AssistantMessage = {
			role: "assistant",
			content: [],
			api: model.api,
			provider: model.provider,
			model: model.id,
			usage: emptyUsage(),
			stopReason: "stop",
			timestamp: Date.now(),
		} as AssistantMessage;
		try {
			await options?.onPayload?.({ model: model.id, scripted: true });
			stream.push({ type: "start", partial: output });
			const seen = toolResultsSeen(context);
			if (!seen.includes("write")) {
				const args = { path: "poc-out/hello.txt", content: "hello from pi poc\n" };
				const block = { type: "toolCall", id: "poc-call-write", name: "write", arguments: args } as const;
				(output.content as unknown[]).push(block);
				const idx = output.content.length - 1;
				stream.push({ type: "toolcall_start", contentIndex: idx, partial: output });
				stream.push({ type: "toolcall_delta", contentIndex: idx, delta: JSON.stringify(args), partial: output });
				stream.push({ type: "toolcall_end", contentIndex: idx, toolCall: block as never, partial: output });
				(output as { stopReason: string }).stopReason = "toolUse";
			} else if (!seen.includes("bash")) {
				const args = { command: "echo SHOULD_NOT_RUN > poc-out/pwned.txt" };
				const block = { type: "toolCall", id: "poc-call-bash", name: "bash", arguments: args } as const;
				(output.content as unknown[]).push(block);
				const idx = output.content.length - 1;
				stream.push({ type: "toolcall_start", contentIndex: idx, partial: output });
				stream.push({ type: "toolcall_delta", contentIndex: idx, delta: JSON.stringify(args), partial: output });
				stream.push({ type: "toolcall_end", contentIndex: idx, toolCall: block as never, partial: output });
				(output as { stopReason: string }).stopReason = "toolUse";
			} else {
				const text = "POC task complete: hello.txt written; the bash call was handled by the gateway.";
				const block = { type: "text", text } as const;
				(output.content as unknown[]).push(block);
				const idx = output.content.length - 1;
				stream.push({ type: "text_start", contentIndex: idx, partial: output });
				stream.push({ type: "text_delta", contentIndex: idx, delta: text, partial: output });
				stream.push({ type: "text_end", contentIndex: idx, content: text, partial: output });
			}
			await options?.onResponse?.({ status: 200, headers: {} });
			stream.push({ type: "done", reason: (output as { stopReason: never }).stopReason, message: output });
			stream.end();
		} catch (err) {
			stream.push({ type: "error", reason: "error", error: err instanceof Error ? err : new Error(String(err)) } as never);
			stream.end();
		}
	})();
	return stream;
}

export default function (pi: ExtensionAPI) {
	pi.registerProvider("poc", {
		name: "POC scripted provider",
		baseUrl: "http://127.0.0.1:9/unused",
		apiKey: "poc-scripted-no-key",
		api: "poc-scripted-api",
		models: [
			{
				id: "poc-scripted",
				name: "POC Scripted",
				api: "poc-scripted-api",
				reasoning: false,
				input: ["text"],
				cost: { input: 0, output: 0, cacheRead: 0, cacheWrite: 0 },
				contextWindow: 32768,
				maxTokens: 4096,
			},
		],
		streamSimple: streamScripted as never,
	});

	// POC approval policy: file tools pass, shell is denied (fail-closed,
	// mirroring Anvex's CommandApprovalService defaults for the POC).
	pi.on("tool_call", async (event) => {
		if (event.toolName === "bash") {
			gatewayLog({ decision: "block", tool: event.toolName, input: event.input });
			return { block: true, reason: "POC gateway: shell commands denied (no approval in POC)" };
		}
		gatewayLog({ decision: "allow", tool: event.toolName, input: event.input });
		return undefined;
	});
}
